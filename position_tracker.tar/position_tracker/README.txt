See http://code.google.com/p/brown-ros-pkg/wiki/position_tracker for documentation.
