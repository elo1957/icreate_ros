See http://code.google.com/p/brown-ros-pkg/wiki/irobot_create_2_1 for documentation.
